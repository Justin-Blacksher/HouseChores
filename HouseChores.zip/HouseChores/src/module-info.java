module HouseChores {
    requires java.desktop;
}